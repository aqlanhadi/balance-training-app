var NAVTREE_DATA =
[ [ "com.xsens.dot.android.sdk", "com/xsens/dot/android/sdk/package-summary.html", [ [ "Classes", null, [ [ "XsensDotSdk", "com/xsens/dot/android/sdk/XsensDotSdk.html", null, "" ] ]
, "" ] ]
, "" ], [ "com.xsens.dot.android.sdk.events", "com/xsens/dot/android/sdk/events/package-summary.html", [ [ "Classes", null, [ [ "XsensDotData", "com/xsens/dot/android/sdk/events/XsensDotData.html", null, "" ] ]
, "" ] ]
, "" ], [ "com.xsens.dot.android.sdk.interfaces", "com/xsens/dot/android/sdk/interfaces/package-summary.html", [ [ "Interfaces", null, [ [ "XsensDotCiCallback", "com/xsens/dot/android/sdk/interfaces/XsensDotCiCallback.html", null, "" ], [ "XsensDotDeviceCallback", "com/xsens/dot/android/sdk/interfaces/XsensDotDeviceCallback.html", null, "" ], [ "XsensDotMeasurementCallback", "com/xsens/dot/android/sdk/interfaces/XsensDotMeasurementCallback.html", null, "" ], [ "XsensDotOtaSimpleCallback", "com/xsens/dot/android/sdk/interfaces/XsensDotOtaSimpleCallback.html", null, "" ], [ "XsensDotRecordingCallback", "com/xsens/dot/android/sdk/interfaces/XsensDotRecordingCallback.html", null, "" ], [ "XsensDotScannerCallback", "com/xsens/dot/android/sdk/interfaces/XsensDotScannerCallback.html", null, "" ], [ "XsensDotSyncCallback", "com/xsens/dot/android/sdk/interfaces/XsensDotSyncCallback.html", null, "" ] ]
, "" ] ]
, "" ], [ "com.xsens.dot.android.sdk.models", "com/xsens/dot/android/sdk/models/package-summary.html", [ [ "Classes", null, [ [ "FilterProfileInfo", "com/xsens/dot/android/sdk/models/FilterProfileInfo.html", null, "" ], [ "XsensDotDevice", "com/xsens/dot/android/sdk/models/XsensDotDevice.html", null, "" ], [ "XsensDotPayload", "com/xsens/dot/android/sdk/models/XsensDotPayload.html", null, "" ], [ "XsensDotRecordingFileInfo", "com/xsens/dot/android/sdk/models/XsensDotRecordingFileInfo.html", null, "" ], [ "XsensDotSyncManager", "com/xsens/dot/android/sdk/models/XsensDotSyncManager.html", null, "" ] ]
, "" ], [ "Enums", null, [ [ "FilterProfileInfo.PropertyType", "com/xsens/dot/android/sdk/models/FilterProfileInfo.PropertyType.html", null, "" ], [ "XsensDotRecordingState", "com/xsens/dot/android/sdk/models/XsensDotRecordingState.html", null, "" ] ]
, "" ] ]
, "" ], [ "com.xsens.dot.android.sdk.ota", "com/xsens/dot/android/sdk/ota/package-summary.html", [ [ "Classes", null, [ [ "XsensDotOtaSimpleManager", "com/xsens/dot/android/sdk/ota/XsensDotOtaSimpleManager.html", null, "" ] ]
, "" ] ]
, "" ], [ "com.xsens.dot.android.sdk.recording", "com/xsens/dot/android/sdk/recording/package-summary.html", [ [ "Classes", null, [ [ "XsensDotRecordingManager", "com/xsens/dot/android/sdk/recording/XsensDotRecordingManager.html", null, "" ] ]
, "" ] ]
, "" ], [ "com.xsens.dot.android.sdk.utils", "com/xsens/dot/android/sdk/utils/package-summary.html", [ [ "Classes", null, [ [ "XsensDotCompatibleUtil", "com/xsens/dot/android/sdk/utils/XsensDotCompatibleUtil.html", null, "" ], [ "XsensDotDebugger", "com/xsens/dot/android/sdk/utils/XsensDotDebugger.html", null, "" ], [ "XsensDotLogger", "com/xsens/dot/android/sdk/utils/XsensDotLogger.html", null, "" ], [ "XsensDotParser", "com/xsens/dot/android/sdk/utils/XsensDotParser.html", null, "" ], [ "XsensDotScanner", "com/xsens/dot/android/sdk/utils/XsensDotScanner.html", null, "" ] ]
, "" ] ]
, "" ] ]

;

